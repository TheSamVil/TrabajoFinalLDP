from flask import Flask, render_template, request

app = Flask(__name__)

diccionario = {
    ":)": "../static/png/003-feliz.png",
    ":(": "../static/png/009-triste.png",
    ":D": "../static/png/005-sonriente.png",
    ";)": "../static/png/018-guino.png",
    ":p": "../static/png/067-sacandolengua.png",
    "xD": "../static/png/058-riendo.png",
    ":-)": "../static/png/003-feliz.png",
    ":-(": "../static/png/009-triste.png",
    "(y)": "../static/png/028-pulgares-arriba.png",
    "(n)": "../static/png/046-pulgares-abajo.png",
    "<3": "../static/png/068-corazon.png",
    "\m/": "../static/png/069-manos-haciendo-el-signo-de-los-cuernos.png",
    ":-0": "../static/png/004-conmocionado.png",
    ":0": "../static/png/004-conmocionado.png",
    ":-|": "../static/png/008-confuso.png",
    ":|": "../static/png/008-confuso.png",
}

@app.route('/')
def home():
    return render_template('./interfazGrafica.html')

def contar_palabras_emojis(mensaje):
    palabras = mensaje.split(" ")
    emojis = [palabra for palabra in palabras if palabra in diccionario]
    cant_palabras = len(palabras)
    cant_emoji = len(emojis)
    palabras = cant_palabras - cant_emoji
    return palabras, len(emojis)

@app.route('/mensaje', methods=['POST'])
def emojiDecode():
    msg = request.form['cadena']
    mensaje = msg.split(" ")
    nuevoMensaje = []
    for palabra in mensaje:
        if palabra in diccionario:
            nuevoMensaje.append(diccionario[palabra] + " ")
        else:
            nuevoMensaje.append(palabra + " ")

    num_palabras, num_emojis = contar_palabras_emojis(msg)
    return render_template('interfazGrafica.html', msge=nuevoMensaje, num_palabras=num_palabras, num_emojis=num_emojis)

                           
if __name__ == "__main__":
    app.run(port=5001, debug=True)
    